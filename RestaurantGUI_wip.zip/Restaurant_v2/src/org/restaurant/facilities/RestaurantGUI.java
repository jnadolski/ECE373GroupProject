package org.restaurant.facilities;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import org.restaurant.people.*;

public class RestaurantGUI extends JFrame {
	private Restaurant res;
	
	private JMenuBar menuBar;
	
	private JMenu fileMenu;
	private JMenu managerMenu;
	private JMenu manageEmployees; // was menuItem
	private JMenu manageShifts;
	private JMenu info;
	private JMenu viewMenu;
	
	private JMenuItem loadFile;
	private JMenuItem saveFile;
	private JMenuItem exit;
	private JMenuItem hireEmployee;
	private JMenuItem fireEmployee;
	private JMenuItem addShift;
	private JMenuItem removeShift;
	private JMenuItem printActions;
	private JMenuItem printEmployees;
	private JMenuItem waiterView;
	private JMenuItem managerView;
	private JMenuItem bartenderView;
	private JMenuItem chefView;
	//private JMenuItem hostessView;
	private JMenuItem hView;
	
	private JButton finishOrder;
	
	private JTextArea queuedList;
	private JTextArea completedList;
	
	private JPanel display;
	private JPanel queuedOrders;
	private JPanel completedOrders;
	
	public RestaurantGUI(String windowTitle, Restaurant r) {
		super(windowTitle);
		res = r;
		display = new JPanel();
		
		setSize(500, 500);
		
		JLabel welcome = new JLabel("<HTML><center>Welcome to " + res.getName() + "."
				+ "<BR>Choose an action from the above menus.</center></HTML>");
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		display.add(welcome);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(display);
		buildRestaurantGUI();
		setVisible(true);
	}
	
	public void buildRestaurantGUI() {
		remove(display);
		JLabel welcome = new JLabel("<HTML><center>Welcome to " + res.getName() + "."
				+ "<BR>Choose an action from the above menus.</center></HTML>");
		
		display = new JPanel();
		
		menuBar = new JMenuBar();
		
		fileMenu = new JMenu("File");
		managerMenu = new JMenu("Manager");
		info = new JMenu("Info");
		viewMenu = new JMenu("View");
		
		loadFile = new JMenuItem("Load File");
		saveFile = new JMenuItem("Save File");
		exit = new JMenuItem("Exit");
		
		hireEmployee = new JMenuItem("Hire Employee");
		fireEmployee = new JMenuItem("Fire Employee");
		
		printActions = new JMenuItem("Print Actions");
		printEmployees = new JMenuItem("Print Employees");
		
		manageEmployees = new JMenu("Manage Employees");
		manageShifts = new JMenu("Manage Shifts");
		
		addShift = new JMenuItem("Add Shift");
		removeShift = new JMenuItem("Remove Shift");
		
		waiterView = new JMenuItem("View as Waiter");
		bartenderView = new JMenuItem("View as Bartender");
		chefView = new JMenuItem("View as Chef");
		//hView = new JMenuItem("Hostess View");
		
		loadFile.addActionListener(new MenuListener());
		saveFile.addActionListener(new MenuListener());
		exit.addActionListener(new MenuListener());
		
		hireEmployee.addActionListener(new MenuListener());
		fireEmployee.addActionListener(new MenuListener());
		
		addShift.addActionListener(new MenuListener());
		removeShift.addActionListener(new MenuListener());
		
		printActions.addActionListener(new MenuListener());
		printEmployees.addActionListener(new MenuListener());
		
		waiterView.addActionListener(new MenuListener());
		bartenderView.addActionListener(new MenuListener());
		chefView.addActionListener(new MenuListener());
		//hView.addActionListener(new MenuListener());
		
		//manageEmployees.addActionListener(new MenuListener());
		
		fileMenu.add(loadFile);
		fileMenu.add(saveFile);
		fileMenu.add(exit);
		
		//managerMenu.add(hireEmployee);
		//managerMenu.add(fireEmployee);
		manageEmployees.add(hireEmployee);
		manageEmployees.add(fireEmployee);
		
		manageShifts.add(addShift);
		manageShifts.add(removeShift);
		
		managerMenu.add(manageEmployees);
		managerMenu.add(manageShifts);
		
		info.add(printActions);
		info.add(printEmployees);
		
		viewMenu.add(waiterView);
		viewMenu.add(bartenderView);
		viewMenu.add(chefView);
		//viewMenu.add(hView);
		
		menuBar.add(fileMenu);
		menuBar.add(managerMenu);
		menuBar.add(info);
		menuBar.add(viewMenu);
		
		display.add(welcome);
		
		setSize(500, 500);
		setJMenuBar(menuBar);
		add(display);
	}
	
	private class MenuListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JMenuItem source = (JMenuItem) e.getSource();
			
			if (source.equals(loadFile)) {
				handleLoadFile();
			}
			
			else if (source.equals(saveFile)) {
				handleSaveFile();
			}
			
			else if (source.equals(exit)) {
				handleExit();
			}
			
			else if (source.equals(hireEmployee)) {
				handleHiring();
			}
			
			else if (source.equals(fireEmployee)) {
				handleFiring();
			}
			
			else if (source.equals(addShift)) {
				handleAddShift();
			}
			
			else if (source.equals(removeShift)) {
				handleRemoveShift();
			}
			
			else if (source.equals(printActions)) {
				handlePrintActions();
			}
			
			else if (source.equals(printEmployees)) {
				handlePrintEmployees();
			}
			
			else if (source.equals(waiterView)) {
				changeToWaiterView();
			}
			
			else if (source.equals(managerView)) {
				buildRestaurantGUI();
			}
			
			else if (source.equals(bartenderView)) {
				changeToBartenderView();
			}
			
			else if (source.equals(chefView)) {
				changeToChefView();
			}
			
			else if (source.equals(hView)) {
				changeToHostessView();
			}
		}
		
		private class ButtonListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				JButton source = (JButton) e.getSource();
				if (source.equals(finishOrder)) {
					handleCompleteOrder();
				}
			}
		}
		
		private void handleLoadFile() {
			res = Restaurant.loadData();
		}
		
		private void handleSaveFile() {
			Restaurant.saveData(res);
		}
		
		private void handleExit() {
			System.exit(0);
		}
		
		private void handleHiring() {
			String position;
			String name;
			String hireDate;
			String pay;
			
			Waiter w = new Waiter();
			Bartender b = new Bartender();
			Chef c = new Chef();
			Hostess h = new Hostess();
			
			int n;
			
			double payRate = 0.0;
			
			
			//Boolean alreadyHired = false;
			
			JPanel parent = new JPanel(new BorderLayout(5, 5));
			JPanel fields = new JPanel(new GridLayout(0, 1, 2, 2));
			JPanel labels = new JPanel(new GridLayout(0, 1, 2, 2));
			
			JTextField posIn = new JTextField(20);
			JTextField nameIn = new JTextField(20);
			JTextField hireIn = new JTextField(20);
			JTextField payIn = new JTextField(20);
			
			labels.add(new JLabel("Position:", SwingConstants.RIGHT));
			labels.add(new JLabel("Employee Name:", SwingConstants.RIGHT));
			labels.add(new JLabel("Hire Date:", SwingConstants.RIGHT));
			labels.add(new JLabel("Pay Rate:", SwingConstants.RIGHT));
			
			parent.add(labels, BorderLayout.WEST);
			
			fields.add(posIn);
			fields.add(nameIn);
			fields.add(hireIn);
			fields.add(payIn);
			
			parent.add(fields, BorderLayout.CENTER);
			
			n = JOptionPane.showConfirmDialog(null, parent, "Hire Employee", JOptionPane.OK_CANCEL_OPTION);
			
			if (n == JOptionPane.OK_OPTION) {
				position = posIn.getText();
				name = nameIn.getText();
				hireDate = hireIn.getText();
				pay = payIn.getText();
				
				if ((position.length() != 0) && (name.length() != 0) && (hireDate.length() != 0) && (pay.length() != 0)) {
					payRate = Double.parseDouble(pay);
					
					if ((position.compareToIgnoreCase("Waiter") == 0) || (position.compareToIgnoreCase("Bartender") == 0) ||
							(position.compareToIgnoreCase("Chef") == 0) || (position.compareToIgnoreCase("Hostess") == 0)) {
					
						if (res.getManager().employeeExists(name)) {
							JOptionPane.showMessageDialog(null, "\"" + name + "\" already works at " + res.getName() + ".", "Error", JOptionPane.ERROR_MESSAGE);
						}
					
						else {
							if (position.compareToIgnoreCase("Waiter") == 0) {
								w.setName(name);
								res.getManager().hireWaiterGUI(w, hireDate);
								JOptionPane.showMessageDialog(null, "Waiter " + name + " was hired.", "Success", JOptionPane.INFORMATION_MESSAGE);
							}
							
							else if (position.compareToIgnoreCase("Bartender") == 0) {
								b.setName(name);
								res.getManager().hireBartenderGUI(b, hireDate);
								JOptionPane.showMessageDialog(null, "Bartender " + name + " was hired.", "Success", JOptionPane.INFORMATION_MESSAGE);
							}
							
							else if (position.compareToIgnoreCase("Chef") == 0) {
								c.setName(name);
								res.getManager().hireChefGUI(c, hireDate);
								JOptionPane.showMessageDialog(null, "Chef " + name + " was hired.", "Success", JOptionPane.INFORMATION_MESSAGE);
							}
							
							else if (position.compareToIgnoreCase("Hostess") == 0) {
								h.setName(name);
								res.getManager().hireHostessGUI(h, hireDate);
							}
						}
					}
					
					else {
						JOptionPane.showMessageDialog(null, "\"" + position + "\" is an invalid position. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					/*for (Waiter w1 : res.getManager().getWaiters()) {
						if (alreadyHired) {
							break;
						}
						
						if (w1.getName().compareToIgnoreCase(name) == 0) {
							JOptionPane.showMessageDialog(null, w1.getName() + " already works as a Waiter.", "Error", JOptionPane.ERROR_MESSAGE);
							alreadyHired = true;
							break;
						}
					}
					
					for (Bartender b1 : res.getManager().getBartenders()) {
						if (alreadyHired) {
							break;
						}
						
						if (b1.getName().compareToIgnoreCase(name) == 0) {
							JOptionPane.showMessageDialog(null, b1.getName() + " already works as a Bartender.", "Error", JOptionPane.ERROR_MESSAGE);
							alreadyHired = true;
							break;
						}
					}
					
					for (Chef c1 : res.getManager().getChefs()) {
						if (alreadyHired) {
							break;
						}
						
						if (c1.getName().compareToIgnoreCase(name) == 0) {
							JOptionPane.showMessageDialog(null, c1.getName() + " already works as a Chef.", "Error", JOptionPane.ERROR_MESSAGE);
							alreadyHired = true;
							break;
						}
					}
					
					for (Hostess h1 : res.getManager().getHostesses()) {
						if (alreadyHired) {
							break;
						}
						
						if (h1.getName().compareToIgnoreCase(name) == 0) {
							JOptionPane.showMessageDialog(null, h1.getName() + " already works as a Hostess.", "Error", JOptionPane.ERROR_MESSAGE);
							alreadyHired = true;
							break;
						}
					}*/
				}
				
				else {
					if (position.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Position\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (name.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Employee Name\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (hireDate.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Hire Date\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (pay.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Pay Rate\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		}
		
		private void handleFiring() {
			//String position;
			String name;
			
			Waiter w = new Waiter();
			Bartender b = new Bartender();
			Chef c = new Chef();
			Hostess h = new Hostess();
			
			int n;
			
			//double payRate = 0.0;
			
			
			//Boolean alreadyHired = false;
			
			JPanel parent = new JPanel(new FlowLayout());
			JPanel fields = new JPanel();
			JPanel labels = new JPanel();
			
			//JTextField posIn = new JTextField(20);
			JTextField nameIn = new JTextField(20);
			//JTextField hireIn = new JTextField(20);
			//JTextField payIn = new JTextField(20);
			
			//labels.add(new JLabel("Position:", SwingConstants.RIGHT));
			labels.add(new JLabel("Employee Name:", SwingConstants.RIGHT));
			//labels.add(new JLabel("Hire Date:", SwingConstants.RIGHT));
			//labels.add(new JLabel("Pay Rate:", SwingConstants.RIGHT));
			
			parent.add(labels, BorderLayout.WEST);
			
			//fields.add(posIn);
			fields.add(nameIn);
			//fields.add(hireIn);
			//fields.add(payIn);
			
			parent.add(fields, BorderLayout.CENTER);
			
			n = JOptionPane.showConfirmDialog(null, parent, "Fire Employee", JOptionPane.OK_CANCEL_OPTION);	
			
			if (n == JOptionPane.OK_OPTION) {
				//position = posIn.getText();
				name = nameIn.getText();
				
				if (name.length() != 0) {
					if (res.getManager().employeeExists(name)) {
						if (name.compareToIgnoreCase(res.getManager().getName()) == 0) {
							JOptionPane.showMessageDialog(null, "A Manager cannot be fired here.", "Error", JOptionPane.ERROR_MESSAGE);
						}
						
						else {
							w = res.getManager().searchWaiter(name);
							if (w.getName().compareToIgnoreCase(name) == 0) {
								res.getManager().fireWaiterGUI(w);
								JOptionPane.showMessageDialog(null, "Waiter " + w.getName() + " was fired.", "Success", JOptionPane.INFORMATION_MESSAGE);
								return;
							}
							
							b = res.getManager().searchBartender(name);
							if (b.getName().compareToIgnoreCase(name) == 0) {
								res.getManager().fireBartenderGUI(b);
								JOptionPane.showMessageDialog(null, "Bartender " + b.getName() + " was fired.", "Success", JOptionPane.INFORMATION_MESSAGE);
								return;
							}
							
							c = res.getManager().searchChef(name);
							if (b.getName().compareToIgnoreCase(name) == 0) {
								res.getManager().fireChefGUI(c);
								JOptionPane.showMessageDialog(null, "Chef " + c.getName() + " was fired.", "Success", JOptionPane.INFORMATION_MESSAGE);
								return;
							}
							
							h = res.getManager().searchHostess(name);
							if (h.getName().compareToIgnoreCase(name) == 0) {
								res.getManager().fireHostessGUI(h);
								JOptionPane.showMessageDialog(null, "Hostess " + h.getName() + " was fired.", "Success", JOptionPane.INFORMATION_MESSAGE);
								return;
							}
							/*if (position.compareToIgnoreCase("Waiter") == 0) {
								w = res.getManager().searchWaiter(name);
								if (w.getName().compareTo("unknown") != 0) {
									res.getManager().fireWaiterGUI(w);
								}
								
								else {
									JOptionPane.showMessageDialog(null, "A Manager cannot be fired here.", "Error", JOptionPane.ERROR_MESSAGE);
								}
							}
							
							else if (position.compareToIgnoreCase("Bartender") == 0) {
								b = (Bartender) res.getManager().searchEmployee(name);
								res.getManager().fireBartenderGUI(b);
							}*/
						}
					}
				
					else {
						JOptionPane.showMessageDialog(null, "Cannot fire \"" + name + "\". " + "\"" + name + "\"" + " doesn't work at " + res.getName() + ".", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
				else {
					JOptionPane.showMessageDialog(null, "The \"Employee Name\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
		
		private void handleAddShift() {
			String name;
			String shift;
			
			Waiter w = new Waiter();
			Bartender b = new Bartender();
			Chef c = new Chef();
			Hostess h = new Hostess();
			
			int n;
			int shiftTime;
			
			JPanel parent = new JPanel(new BorderLayout(5, 5));
			JPanel fields = new JPanel(new GridLayout(0, 1, 2, 2));
			JPanel labels = new JPanel(new GridLayout(0, 1, 2, 2));
			
			JTextField nameIn = new JTextField(20);
			JTextField shiftIn = new JTextField(20);
			
			labels.add(new JLabel("Employee Name:", SwingConstants.RIGHT));
			labels.add(new JLabel("Shift Code:", SwingConstants.RIGHT));
			
			parent.add(labels, BorderLayout.WEST);
			
			fields.add(nameIn);
			fields.add(shiftIn);
			
			parent.add(fields, BorderLayout.CENTER);
			
			n = JOptionPane.showConfirmDialog(null, parent, "Add Shift", JOptionPane.OK_CANCEL_OPTION);
			
			if (n == JOptionPane.OK_OPTION) {
				name = nameIn.getText();
				shift = shiftIn.getText();
				
				if ((name.length() != 0) && (shift.length() != 0)) {
					shiftTime = Integer.parseInt(shift);
					
					if (res.getManager().employeeExists(name)) {
						if (res.getManager().getName().compareToIgnoreCase(name) == 0) {
							if (res.getManager().hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Manager " + res.getManager().getName() + " already works the \"" + shiftTime + "\" shift. ", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().addShiftGUI(res.getManager(), shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was added to Manager " + res.getManager().getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						w = res.getManager().searchWaiter(name);
						if (w.getName().compareToIgnoreCase(name) == 0) {
							if (w.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Waiter " + w.getName() + " already works the \"" + shiftTime + "\" shift. ", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().addShiftGUI(w, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was added to Waiter " + w.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						b = res.getManager().searchBartender(name);
						if (b.getName().compareToIgnoreCase(name) == 0) {
							if (b.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Bartender " + b.getName() + " already works the \"" + shiftTime + "\" shift. ", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().addShiftGUI(b, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was added to Bartender " + b.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						c = res.getManager().searchChef(name);
						if (b.getName().compareToIgnoreCase(name) == 0) {
							if (c.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Chef " + c.getName() + " already works the \"" + shiftTime + "\" shift. ", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().addShiftGUI(c, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was added to Chef " + c.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						h = res.getManager().searchHostess(name);
						if (h.getName().compareToIgnoreCase(name) == 0) {
							if (h.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Hostess " + h.getName() + " already works the \"" + shiftTime + "\" shift. ", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().addShiftGUI(h, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was added to Hostess " + h.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}						
					}
					
					else {
						JOptionPane.showMessageDialog(null, name + " is not an employee at " + res.getName() + ".", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
				else {
					if (name.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Employee Name\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (shift.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Shift Code\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		}
		
		private void handleRemoveShift() {
			String name;
			String shift;
			
			Waiter w = new Waiter();
			Bartender b = new Bartender();
			Chef c = new Chef();
			Hostess h = new Hostess();
			
			int n;
			int shiftTime;
			
			JPanel parent = new JPanel(new BorderLayout(5, 5));
			JPanel fields = new JPanel(new GridLayout(0, 1, 2, 2));
			JPanel labels = new JPanel(new GridLayout(0, 1, 2, 2));
			
			JTextField nameIn = new JTextField(20);
			JTextField shiftIn = new JTextField(20);
			
			labels.add(new JLabel("Employee Name:", SwingConstants.RIGHT));
			labels.add(new JLabel("Shift Code:", SwingConstants.RIGHT));
			
			parent.add(labels, BorderLayout.WEST);
			
			fields.add(nameIn);
			fields.add(shiftIn);
			
			parent.add(fields, BorderLayout.CENTER);
			
			n = JOptionPane.showConfirmDialog(null, parent, "Remove Shift", JOptionPane.OK_CANCEL_OPTION);
			
			if (n == JOptionPane.OK_OPTION) {
				name = nameIn.getText();
				shift = shiftIn.getText();
				
				if ((name.length() != 0) && (shift.length() != 0)) {
					shiftTime = Integer.parseInt(shift);
					
					if (res.getManager().employeeExists(name)) {
						
						if (res.getManager().getName().compareToIgnoreCase(name) == 0) {
							if (!res.getManager().hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Cannot remove \"" + shiftTime + "\" from Manager " + res.getManager().getName() + "'s Schedule.\n" + 
										"Manager " + res.getManager().getName() + "does not work the \"" + shiftTime + "\" shift.", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().removeShiftGUI(res.getManager(), shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was removed from Manager " + res.getManager().getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						w = res.getManager().searchWaiter(name);
						if (w.getName().compareToIgnoreCase(name) == 0) {
							if (!w.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Cannot remove \"" + shiftTime + "\" from Watier " + w.getName() + "'s Schedule.\n" + 
										"Waiter " + w.getName() + "does not work the \"" + shiftTime + "\" shift.", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().removeShiftGUI(w, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was removed from Waiter " + w.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						b = res.getManager().searchBartender(name);
						if (b.getName().compareToIgnoreCase(name) == 0) {
							if (!b.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Cannot remove \"" + shiftTime + "\" from Bartender " + b.getName() + "'s Schedule.\n" + 
										"Bartender " + b.getName() + "does not work the \"" + shiftTime + "\" shift.", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().removeShiftGUI(b, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was removed from Bartender " + b.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						c = res.getManager().searchChef(name);
						if (c.getName().compareToIgnoreCase(name) == 0) {
							if (!c.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Cannot remove \"" + shiftTime + "\" from Chef " + c.getName() + "'s Schedule.\n" + 
										"Chef " + c.getName() + "does not work the \"" + shiftTime + "\" shift.", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().removeShiftGUI(c, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was removed from Chef " + c.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
						
						h = res.getManager().searchHostess(name);
						if (h.getName().compareToIgnoreCase(name) == 0) {
							if (!h.hasShift(shiftTime)) {
								JOptionPane.showMessageDialog(null, "Cannot remove \"" + shiftTime + "\" from Hostess " + h.getName() + "'s Schedule.\n" + 
										"Hostess " + h.getName() + "does not work the \"" + shiftTime + "\" shift.", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							res.getManager().removeShiftGUI(h, shiftTime);
							JOptionPane.showMessageDialog(null, "Shift time \"" + shiftTime + "\" was removed from Hostess " + h.getName() + "'s Schedule.", "Success", JOptionPane.INFORMATION_MESSAGE);
							return;
						}						
					}
					
					else {
						JOptionPane.showMessageDialog(null, name + " is not an employee at " + res.getName() + ".", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
				else {
					if (name.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Employee Name\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (shift.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Shift Code\" field recieved an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}			
		}
		
		private void handlePrintActions() {
			String actions;
			
			//actions = 
		}
		
		private void handlePrintEmployees() {
			
		}
		
		private void handleCompleteOrder() {
			String name;
			String orderNum;
			
			Chef c = new Chef();
			
			int index;
			int n;
			
			JPanel parent = new JPanel(new BorderLayout(5, 5));
			JPanel fields = new JPanel(new GridLayout(0, 1, 2, 2));
			JPanel labels = new JPanel(new GridLayout(0, 1, 2, 2));
			
			JTextField nameIn = new JTextField(20);
			JTextField orderNumIn = new JTextField(20);
			
			labels.add(new JLabel("Chef Name:", SwingConstants.RIGHT));
			labels.add(new JLabel("Order #:", SwingConstants.RIGHT));
			
			parent.add(labels, BorderLayout.WEST);
			
			fields.add(nameIn);
			fields.add(orderNumIn);
			
			parent.add(fields, BorderLayout.CENTER);
			
			n = JOptionPane.showConfirmDialog(null, parent, "Complete an Order", JOptionPane.OK_CANCEL_OPTION);
			
			if (n == JOptionPane.OK_OPTION) {
				name = nameIn.getText();
				orderNum = orderNumIn.getText();
				
				if ((name.length() != 0) && (orderNum.length() != 0)) {
					index = Integer.parseInt(orderNum);
					
					c = res.getManager().searchChef(name);
					if (c.getName().compareToIgnoreCase(name) == 0) {
						if ((index <= c.getQueuedOrders().size()) && (index > 0)) {
							c.completeOrder(index - 1);
							changeToChefView();
						}
						
						else {
							JOptionPane.showMessageDialog(null, "The index " + index + " is out of range. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
						}
					}
					
					else {
						JOptionPane.showMessageDialog(null, name + " is not a Chef. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
				else {
					if (name.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Chef Name\" field received an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (orderNum.length() == 0) {
						JOptionPane.showMessageDialog(null, "The \"Order #\" field received an empty input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		}
		
		private void changeToWaiterView() {
			//removeAll();
			remove(display);
			display = new JPanel();
			
			JLabel welcome = new JLabel("<HTML><center>Welcome to the Waiter View."
					+ "<BR>Choose an action from the above menus.</center></HTML>");
		    
			menuBar = new JMenuBar();
			
			managerView = new JMenuItem("View as Manager");
			bartenderView = new JMenuItem("View as Bartender");
			chefView = new JMenuItem("View as Chef");
			hView = new JMenuItem("View as Hostess");
			
			viewMenu = new JMenu("View");
			
			managerView.addActionListener(new MenuListener());
			bartenderView.addActionListener(new MenuListener());
			chefView.addActionListener(new MenuListener());
			hView.addActionListener(new MenuListener());
			
			viewMenu.add(managerView);
			viewMenu.add(bartenderView);
			viewMenu.add(chefView);
			viewMenu.add(hView);
			
			menuBar.add(viewMenu);
			
			setJMenuBar(menuBar);
			
			setSize(400, 400);
			
			display.add(welcome);
			add(display);
		}
		
		private void changeToBartenderView() {
			remove(display);
			display = new JPanel();
			
			JLabel welcome = new JLabel("<HTML><center>Welcome to the Bartender View."
					+ "<BR>Choose an action from the above menus.</center></HTML>");
		    
			menuBar = new JMenuBar();
			
			managerView = new JMenuItem("View as Manager");
			waiterView = new JMenuItem("View as Waiter");
			chefView = new JMenuItem("View as Chef");
			hView = new JMenuItem("View as Hostess");
			
			viewMenu = new JMenu("View");
			
			managerView.addActionListener(new MenuListener());
			waiterView.addActionListener(new MenuListener());
			chefView.addActionListener(new MenuListener());
			hView.addActionListener(new MenuListener());
			
			viewMenu.add(managerView);
			viewMenu.add(waiterView);
			viewMenu.add(chefView);
			viewMenu.add(hView);
			
			menuBar.add(viewMenu);
			
			setJMenuBar(menuBar);
			
			setSize(600, 600);
			
			display.add(welcome);
			add(display);
		}
		
		private void changeToChefView() {
			remove(display);
			
			String queue = "";
			String completed = "";
			
			//JScrollPane scrollable1 = new JScrollPane(queue, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			
			queuedList = new JTextArea();
			completedList = new JTextArea();
			
			display = new JPanel(new GridLayout(0, 1, 2, 2));
			
			queuedOrders = new JPanel(new GridLayout(1, 2));
			completedOrders = new JPanel(new GridLayout(1, 2));
			
			queuedOrders.setBorder(BorderFactory.createTitledBorder("Queued Orders"));
			completedOrders.setBorder(BorderFactory.createTitledBorder("Completed Orders"));
			
			JLabel welcome = new JLabel("<HTML><center>Welcome to the Chef View."
					+ "<BR>To change views, choose from the menu above.</center></HTML>");
		    
			menuBar = new JMenuBar();
			managerView = new JMenuItem("Manager View");
			bartenderView = new JMenuItem("Bartender View");
			waiterView = new JMenuItem("Waiter View");
			hView = new JMenuItem("Hostess View");
			
			viewMenu = new JMenu("View");
			
			managerView.addActionListener(new MenuListener());
			bartenderView.addActionListener(new MenuListener());
			waiterView.addActionListener(new MenuListener());
			hView.addActionListener(new MenuListener());
			
			viewMenu.add(managerView);
			viewMenu.add(bartenderView);
			viewMenu.add(waiterView);
			viewMenu.add(hView);
			
			menuBar.add(viewMenu);
			
			setJMenuBar(menuBar);
			
			setSize(600, 400);
			
			finishOrder = new JButton("Complete an Order");
			finishOrder.addActionListener(new ButtonListener());
			
			for (Chef c : res.getManager().getChefs()) {
				queue = queue + c.printQueuedOrdersGUI();
				queue = queue + "\n";
			}
			
			for (Chef c : res.getManager().getChefs()) {
				completed = completed + c.printCompletedOrdersGUI();
				completed = completed + "\n";
			}
			
			queuedList.setEditable(false);
			completedList.setEditable(false);
			
			queuedList.setText(queue);
			
			JScrollPane scrollable1 = new JScrollPane(queuedList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			//queuedOrders.add(queuedList);
			scrollable1.setSize(100, 50);
			queuedOrders.add(scrollable1);
			
			completedList.setText(completed);
			
			JScrollPane scrollable2 = new JScrollPane(completedList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			//completedOrders.add(completedList);
			scrollable2.setSize(100, 50);
			completedOrders.add(scrollable2);
			
			display.add(welcome);
			display.add(queuedOrders);
			display.add(completedOrders);
			display.add(finishOrder);
			
			add(display);
			pack();
		}
		
		private void changeToHostessView() {
			remove(display);
			display = new JPanel();
			
			JLabel welcome = new JLabel("<HTML><center>Welcome to the Hostess View."
					+ "<BR>Choose an action from the above menus.</center></HTML>");
		    
			menuBar = new JMenuBar();
			//managerView = new JMenuItem("Manager View");
			bartenderView = new JMenuItem("View as Bartender");
			chefView = new JMenuItem("View as Chef");
			waiterView = new JMenuItem("View as Waiter");
			
			viewMenu = new JMenu("View");
			
			//managerView.addActionListener(new MenuListener());
			bartenderView.addActionListener(new MenuListener());
			chefView.addActionListener(new MenuListener());
			waiterView.addActionListener(new MenuListener());
			
			//viewMenu.add(managerView);
			viewMenu.add(bartenderView);
			viewMenu.add(chefView);
			viewMenu.add(waiterView);
			
			menuBar.add(viewMenu);
			
			setJMenuBar(menuBar);
			
			setSize(500, 500);
			
			display.add(welcome);
			add(display);
		}
	}
}
