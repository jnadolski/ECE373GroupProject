package org.restaurant.people;

import java.util.ArrayList;

import org.restaurant.supplies.Food;

public class Chef extends Employee {
	// Attributes;
	private ArrayList<Food> queuedOrders;
	//private ArrayList<Food> preparingOrders;
	private ArrayList<Food> completedOrders;
	
	// Constructor;
	public Chef() {
		queuedOrders = new ArrayList<Food>();
		//preparingOrders = new ArrayList<Food>();
		completedOrders = new ArrayList<Food>();
	}
	
	// Methods;
	public void queueOrder(Food order) {
//		for (Food f : this.getRestaurant().getFoodMenu()) {
//			if (f.getName().compareTo(order.getName()) == 1) {
//				queuedOrders.add(order);
//				return;
//			}
//		}
//		
//		System.out.println("Chef " + this.getName() + " cannot prepare " + order.getName() + " because it is not in Restaurant " + this.getRestaurant().getName() + "'s menu.");
		queuedOrders.add(order);
	}
	
	public ArrayList<Food> getQueuedOrders() {
		return queuedOrders;
	}
	
	public ArrayList<Food> getCompletedOrders() {
		return completedOrders;
	}
	
	public void completeOrder(int index) {
		queuedOrders.get(index).completeOrder();
		completedOrders.add(queuedOrders.get(index));
		queuedOrders.remove(index);
	}
	
	public void printQueuedOrders() {
		System.out.println("Chef " + this.getName() + "'s Queued Orders: ");
		int placeInQueue = 1; 
		for(Food f : queuedOrders) {
			System.out.println(placeInQueue + ". " + f.getName());
			placeInQueue++; 
		}
	}
	
	public void printCompletedOrders() {
		System.out.println("Chef " + this.getName() + "'s Completed Orders: ");
		for(Food f : completedOrders) {
			System.out.println("   " + f.getName());
		}
	}
	
	public String printQueuedOrdersGUI() {
		String queued = "";
		int placeInQueue = 1;
		
		queued = queued + "Chef " + this.getName() + "'s Queued Orders:\n";
		
		for (Food f : queuedOrders) {
			queued = queued + "\t" + placeInQueue + ". " + f.getName() + "\n";
			placeInQueue++;
		}
		
		return queued;
	}
	
	public String printCompletedOrdersGUI() {
		String completed = "";
		int placeInComplete = 1;
		
		completed = completed + "Chef " + this.getName() + "'s Completed Orders:\n";
		for(Food f : completedOrders) {
			completed = completed + "\t" + f.getName() + "\n";
			placeInComplete++;
		}
		
		return completed;
	}
}